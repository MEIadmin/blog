<template>
  <div class="all">
    仓库中的宝贝
  </div>
</template>
<script>
export default {
  data() {
    return {

    }
  }
}
</script>

