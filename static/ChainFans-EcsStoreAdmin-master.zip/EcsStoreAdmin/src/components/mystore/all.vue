<template>
  <div class="all">
    所有商品
  </div>
</template>
<script>
export default {
  data() {
    return {

    }
  }
}
</script>
