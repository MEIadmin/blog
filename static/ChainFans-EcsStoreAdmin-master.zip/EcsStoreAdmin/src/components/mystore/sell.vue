<template>
  <div class="all">
    <div class="search">
      <div class="search-cont">
        <p>商品标题：<el-input v-model="goodtitle" placeholder="请输入内容" class="search-input" /></p>
        <p>一级类目：<el-input v-model="firsttype" placeholder="请输入内容" class="search-input" /></p>
      </div>
      <div class="search-cont">
        <p>商铺&nbsp;&nbsp;&nbsp;&nbsp;ID：<el-input v-model="shopname" placeholder="请输入内容" class="search-input" /></p>
        <p>店铺分类： <el-cascader :options="shoptype" class="more-select" /></p>
      </div>
      <div class="search-cont">
        <p>商家编码：<el-input v-model="shopid" placeholder="请输入内容" class="search-input" /></p>
        <p>宝贝类型： <el-cascader :options="goodtype" class="more-select" /></p>
      </div>
      <div class="search-cont">
        <p>价格：<el-input v-model="lowpay" placeholder="最低" class="pay" />--<el-input v-model="heightpay" placeholder="最高" class="pay" /></p>
        <p>销量：<el-input v-model="lowsale" placeholder="最低" class="pay" />--<el-input v-model="heightsale" placeholder="最高" class="pay" /></p>
      </div>
      <div class="submit-search">
        <div class="submit-btn-group">
          <el-button size="small">查询</el-button>
          <el-button size="small">重置结果</el-button>
        </div>
      </div>
    </div>

    <div class="many-handle">
      <el-button size="small">批量删除</el-button>
      <el-button size="small">批量下架</el-button>
    </div>
    <div class="good">
      <el-table ref="multipleTable" :data="allgood" tooltip-effect="dark" style="width: 100%">
        <el-table-column type="selection" width="55" />
        <el-table-column prop="name" label="商品名称" width="300">
          <template slot-scope="scope">
            <div class="good-name">
              <div class="name-left">
                <img :src="scope.row.head_pic" width="60" height="60" class="head_pic">
              </div>
              <div class="name-right">
                <p style="color:#1890ff;font-size:16px;">{{ scope.row.name }}</p>
                <p style="font-size:12px;">商品id：123455544</p>

              </div>
            </div>
          </template>
        </el-table-column>
        <el-table-column prop="pay" label="价格">
          <template slot-scope="scope">
            <p style="color:rgb(208, 2, 27);">{{ scope.row.pay }}<span>元</span></p>
          </template>
        </el-table-column>
        <el-table-column prop="store" label="库存" />
        <el-table-column prop="sell" label="销量" />
        <el-table-column prop="starttime" label="创建时间">
          <template slot-scope="scope">
            <p>{{ scope.row.starttime }}</p>
            <p style="color: #7ed321;">出售中</p>
          </template>

        </el-table-column>
        <el-table-column prop="pushtime" label="发布时间" />
        <el-table-column label="操作" width="150">
          <template slot-scope="scope">
            <div class="editshop">
              <el-button size="mini" type="primary">编辑</el-button>
              <el-button size="mini" type="danger">下架</el-button>
            </div>
          </template>
        </el-table-column>
      </el-table>
    </div>
  </div>
</template>
<script>
export default {
  data() {
    return {
      goodtitle: '',
      firsttype: '',
      shopname: '',
      shopid: '',
      lowpay: 0,
      heightpay: '',
      lowsale: 0,
      heightsale: '',
      shoptype: [
        {
          value: 'xxkf',
          label: '系统开发'
        },
        {
          value: 'wz',
          label: '网站开发'
        }
      ],
      goodtype: [
        {
          value: 'xxkf',
          label: '系统开发'
        },
        {
          value: 'wz',
          label: '网站开发'
        }
      ],
      allgood: [
        {
          name: '区块链产品a',
          pay: 120,
          store: 100,
          sell: 333,
          starttime: '2019-5-20 15:08',
          pushtime: '2019-5-20 15:22'
        },
        {
          name: '区块链产品b',
          pay: 120,
          store: 100,
          sell: 333,
          starttime: '2019-5-20 15:08',
          pushtime: '2019-5-20 15:22'
        }
      ]
    }
  }
}
</script>
<style>
.search{display: flex;flex-direction: row;flex-wrap: wrap;}
.search-cont{width: 25%;height: 180px;}
.search-input{max-width: 180px;}
.more-select{max-width: 180px;}
.submit-search{width: 100%;}
.submit-btn-group{width: 200px;margin: 0 auto;}
/* 批量操作 */
.many-handle{height: 32px;margin-top: 16px;margin-bottom: 16px; }
.good-name{display: flex;flex-direction: row;flex-wrap: wrap;}
.name-left{display: inline-flex;align-items: center;}
.name-right{margin-left: 10px;}
.pay{max-width: 80px;}
.editshop{display: flex;flex-direction:row;}
@media screen and (max-width: 1024px){
.search-cont{width: 50%;height: 180px;}
.search-input{max-width: 100px;}

}
</style>

