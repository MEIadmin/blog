<template>
  <div class="login">
    <div class="login-top">

      <div class="company-title">
        <p class="c-title">Ecstore</p>

      </div>
    </div>
    <div class="login-cont">
      <div class="login-form-wrap">
        <div class="login-main">
          <div v-if="changeShow" class="mian-one">
            <el-form ref="loginForm" :model="loginForm" :rules="loginRules" class="login-form" auto-complete="on" label-position="left">

              <el-form-item prop="username" style="margin-top:40px;">
                <span class="svg-container">
                  <svg-icon icon-class="user" />
                </span>
                <el-input
                  ref="username"
                  v-model="loginForm.username"
                  class="el-input"
                  placeholder="Username"
                  name="username"
                  type="text"
                  tabindex="1"
                  auto-complete="on"
                />
              </el-form-item>

              <el-form-item prop="password">
                <span class="svg-container">
                  <svg-icon icon-class="password" />
                </span>
                <el-input
                  :key="passwordType"
                  ref="password"
                  v-model="loginForm.password"
                  :type="passwordType"
                  placeholder="Password"
                  name="password"
                  tabindex="2"
                  auto-complete="on"
                  @keyup.enter.native="handleLogin"
                />

              </el-form-item>

              <el-button :loading="loading" type="primary" style="width:100%;margin-bottom:30px;" @click.native.prevent="handleLogin">登陆</el-button>

            </el-form>
          </div>
          <div v-else class="mian-two">
            <img src="/shop/login/ewm.png" alt="">
            <p style="font-size:12px;">扫码登陆更懂你的心</p>
          </div>
          <div class="change-login" @click="changeLogin">
            切换登陆
          </div>

        </div>

      </div>

    </div>
    <div class="login-footer">底部</div>
  </div>
</template>
<script>
import { validUsername } from '@/utils/validate'

export default {
  name: 'Login',
  data() {
    const validateUsername = (rule, value, callback) => {
      if (!validUsername(value)) {
        callback(new Error('Please enter the correct user name'))
      } else {
        callback()
      }
    }
    const validatePassword = (rule, value, callback) => {
      if (value.length < 6) {
        callback(new Error('The password can not be less than 6 digits'))
      } else {
        callback()
      }
    }
    return {
      loginForm: {
        username: 'admin',
        password: '111111'

      },
      loginRules: {
        username: [{ required: true, trigger: 'blur', validator: validateUsername }],
        password: [{ required: true, trigger: 'blur', validator: validatePassword }]
      },
      loading: false,
      passwordType: 'password',
      redirect: undefined,
      changeShow: true
    }
  },
  watch: {
    $route: {
      handler: function(route) {
        this.redirect = route.query && route.query.redirect
      },
      immediate: true
    }
  },
  methods: {

    handleLogin() {
      this.$refs.loginForm.validate(valid => {
        if (valid) {
          this.loading = true
          this.$store.dispatch('user/login', /* this.loginForm*/).then(() => {
            this.$router.push({ path: this.redirect || '/' })
            this.loading = false
          }).catch(() => {
            this.loading = false
          })
        } else {
          console.log('error submit!!')
          return false
        }
      })
    },
    changeLogin() {
      this.changeShow = !this.changeShow
    }
  }
}
</script>
<style lang="scss">
.login{height:100vh;}
.login-top{width: 100%;height: 44px;margin-top: 22px;margin-bottom: 22px;}
.c-title{font-size: 30px;color: #409eff;}
.company-title{width: 1200px;margin:  0 auto;}
.login-cont{background-image: url('/shop/login/login-bg.jpg');height: 600px;}
.login-form-wrap{width: 1200px;margin: 0 auto;}
.login-main{float: right;position: relative;margin-top: 100px;width: 325px;height: 325px;padding: 25px;background-color: rgba(250,250,250,0.9);}
.svg-container{width: 14px;height: 14px;}
.el-input{width: calc(90%);margin-left: 8px;}
.change-login{
  position: absolute;
  top: 0px;
  right: 0px;
  z-index: 10;
  width: 50px;
  height: 50px;
  background-color: #fff;
}
.mian-two{
  width: 300px;
  height: 300px;
  margin-top: 50px;
  margin-left: 70px;
}

</style>

