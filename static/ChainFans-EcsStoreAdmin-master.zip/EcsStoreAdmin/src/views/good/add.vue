<template>
  <div class="addgood">
    <div class="base-info">
      <div class="title">
        基本信息
      </div>
      <div class="good">

        <div class="cont">
          <div class="left">
            <span>商品类型：</span>
          </div>
          <div class="right">
            <el-cascader :options="goodtype" />
          </div>
        </div>
        <div class="cont">
          <div class="left">
            <span>商品标题：</span>
          </div>
          <div class="right">
            <el-input v-model="goodtitle" placeholder="请输入内容" class="good-title" />
          </div>
        </div>

      </div>
    </div>
    <div class="sale">
      <div class="title">
        销售信息
      </div>
      <div class="good">

        <div class="cont">
          <div class="left">
            <span>主币种：</span>
          </div>
          <div class="right">
            <el-input v-model="goodtitle" placeholder="请输入内容" class="main-rmb" />
          </div>
        </div>
        <div class="cont">
          <div class="left">
            <span>次币种：</span>
          </div>
          <div class="right">
            <el-input v-model="goodtitle" placeholder="请输入内容" class="other-rmb" />
          </div>
        </div>

      </div>
    </div>
    <div class="model">
      <div class="title">
        自定义规格
      </div>
      <div class="good">
        <div class="cont">
          <div class="left">
            颜色分类：
          </div>
          <div class="right">
            <div class="color-wrap">
              <div v-for="colortype in colortypes" :key="colortype.index" class="color-type">
                <el-input v-model="colortype.color" placeholder="请输入内容" class="color-input" />
                <el-upload class="upload-demo" action="https://jsonplaceholder.typicode.com/posts/" list-type="picture">
                  <el-button size="small" type="primary">点击上传</el-button>

                </el-upload>
              </div>
            </div>
            <el-button type="primary" size="small" style="max-width:80px;" @click="addcolor">添加</el-button>
            <el-button type="primary" size="small" style="max-width:80px;" @click="closecolor">删除</el-button>
            <el-button type="primary" size="small" style="max-width:80px;" @click="confirmcolor">确定</el-button>
          </div>
        </div>
        <div class="cont">
          <div class="left">
            <span>规格：</span>
          </div>
          <div class="right">
            <div class="color-wrap">
              <div v-for="sizetype in sizetypes" :key="sizetype.index" class="color-type">
                <el-input v-model="sizetype.size" placeholder="请输入内容" class="color-input" />

              </div>

            </div>
            <el-button type="primary" size="small" style="max-width:80px;" @click="addsize">添加</el-button>
            <el-button type="primary" size="small" style="max-width:80px;" @click="closesize">删除</el-button>
            <el-button type="primary" size="small" style="max-width:80px;" @click="confirmsize">确定</el-button>
          </div>
        </div>
        <div class="cont">
          <div class="left">
            <span>整体展示：</span>
          </div>
          <div class="right">
            <div class="myshow">
              <el-table :data="goodattrs" style="width: 100%" :span-method="arraySpanMethod">

                <el-table-column v-if="colortypes.lenght!==0" fixed prop="color" label="颜色" width="150" />
                <el-table-column v-if="sizetypes.lenght!==0" prop="size" label="规格" />
                <el-table-column prop="pay" label="价格">
                  <template slot-scope="scope">
                    <el-input v-model="scope.row.pay" placeholder="请输入内容" />
                  </template>
                </el-table-column>
                <el-table-column prop="num" label="库存">
                  <template slot-scope="scope">
                    <el-input v-model="scope.row.num" placeholder="请输入内容" />
                  </template>
                </el-table-column>

              </el-table>
            </div>
          </div>
        </div>

      </div>
    </div>

    <div class="datail">
      <div class="title">
        商品信息
      </div>
      <div class="good">

        <div class="cont">
          <div class="left">
            <span>商品图片：</span>
          </div>
          <div class="right">
            <el-upload action="https://jsonplaceholder.typicode.com/posts/" multiple list-type="picture-card">
              <i class="el-icon-plus" />
            </el-upload>
            <el-dialog :visible.sync="dialogVisible" size="tiny">
              <img width="100%" :src="dialogImageUrl" alt="">
            </el-dialog>
          </div>
        </div>
        <div class="cont">
          <div class="left">
            <span>电脑端详情：</span>
          </div>
          <div class="right">
            <el-upload class="upload-demo" action="https://jsonplaceholder.typicode.com/posts/" :file-list="fileList2" list-type="picture">
              <el-button size="small" type="primary">点击上传</el-button>
              <div slot="tip" class="el-upload__tip">图片宽度:750px;最大不可超过3M</div>
            </el-upload>
          </div>
        </div>

      </div>
    </div>
    <div class="transplot">
      <div class="title">
        物流信息
      </div>
      <div class="good">

        <div class="cont">
          <div class="left">
            <span>发货地：</span>
          </div>
          <div class="right">
            <el-cascader v-model="orgintranspolt" :options="orgintranspolt" />
          </div>
        </div>
        <div class="cont">
          <div class="left">
            <span>详细地址：</span>
          </div>
          <div class="right">
            <el-input v-model="detailadress" placeholder="请输入内容" class="detail-adress" />
          </div>
        </div>
        <div class="cont">
          <div class="left">
            <span>首件运费：</span>
          </div>
          <div class="right">
            <el-input v-model="transplotpay" placeholder="请输入内容" class="transplotpay" />
            <span style="font-size:8px;">元</span>
          </div>
        </div>
        <div class="cont">
          <div class="left">
            <span>续件运费：</span>
          </div>
          <div class="right">
            <el-input v-model="otherpay" placeholder="请输入内容" class="otherpay" />
            <span style="font-size:8px;">元</span>
          </div>
        </div>
        <div class="cont">
          <div class="left">
            <span>卖家是否承担运费：</span>
          </div>
          <div class="right">
            <el-switch v-model="freetransplot" />
          </div>
        </div>
        <div class="cont">
          <div class="left">
            <span>配送方式：</span>
          </div>
          <div class="right" style="line-height:30px;">
            <el-radio-group v-model="transplotmethon">
              <el-radio :label="1">快递</el-radio>
              <el-radio :label="2">EMS</el-radio>
              <el-radio :label="3">平邮</el-radio>
            </el-radio-group>
          </div>
        </div>
        <div class="cont">
          <div class="left">
            <span>发货时间：</span>
          </div>
          <div class="right">
            <el-cascader :options="transplottime" />
            <span style="font-size:12px;">(请如实填写发货时间，可以尽量避免商品纠纷)</span>
          </div>
        </div>

      </div>
    </div>
    <div class="servie">
      <div class="title">
        商品服务
      </div>
      <div class="good">

        <div class="cont">
          <div class="left" />
          <div class="right">
            <el-checkbox-group v-model="servie" style="display:flex;flex-direction: column;">
              <el-checkbox label="fp" style="margin-top:8px;margin-bottom:8px;">提供发票(如果填写请注意发票抬头信息)</el-checkbox>
              <el-checkbox label="bx" style="margin-top:8px;margin-bottom:8px;">保修服务</el-checkbox>
              <el-checkbox label="th" style="margin-top:8px;margin-bottom:8px;">退换货承诺(但凡使用支付宝，在本商场下单进行购买的用户，在7天之内免费更换)</el-checkbox>

            </el-checkbox-group>
          </div>
        </div>

      </div>
    </div>

    <div class="submit">
      <el-button type="primary">发布商品</el-button>
      <el-button type="primary">暂存商品</el-button>
    </div>

  </div>
</template>
<script>

export default {
  data() {
    return {

      goodtitle: '',
      goodtype: [
        {
          value: 'xxkf',
          label: '系统开发',
          children: [
            {
              value: 'scxt',
              label: '商场系统',
              children: [
                {
                  value: 'khd',
                  label: '客户端开发'
                }
              ]
            },
            {
              value: 'sj',
              label: '手机系统'
            }
          ]
        },
        {
          value: 'app',
          label: '混流app',
          children: [
            {
              value: 'h5',
              label: '传统h5'
            },
            {
              value: 'xysh',
              label: '响应式开发'
            }
          ]

        }

      ],
      goodattrs: [

      ],
      // 规格参数配置
      colortypes: [
        { color: 'red', url: '#' }

      ],
      sizetypes: [
        { size: 'small' }

      ],

      // 上传参数配置
      dialogImageUrl: '',
      dialogVisible: false,
      fileList2: [
        {
          name: '商品详情',
          url: '/shop/login/login-bg.jpg'
        }
      ],
      // 物流参数配置
      orgintranspolt: [
        {
          value: 'hb',
          label: '湖北省',
          children: [
            {
              value: 'wh',
              label: '武汉市'
            },
            {
              value: 'hg',
              label: '黄冈市'
            }
          ]
        },
        {
          value: 'hn',
          label: '湖南省'
        }
      ],
      detailadress: '',
      transplotpay: '',
      otherpay: '',
      transplotpay: '',
      freetransplot: true,
      transplotmethon: 2,
      transplottime: [
        {
          value: 12,
          label: '12小时以内'
        },
        {
          value: 24,
          label: '24小时以内'
        },
        {
          value: 48,
          label: '48小时以内'
        }
      ],
      // 提供服务参数
      servie: ['fp', '']
    }
  },
  mounted() {

  },
  methods: {
    addcolor() {
      this.colortypes.push({ color: 'new', url: '#' })
      this.changetable()
    },
    confirmcolor() {
      this.changetable()
    },
    closecolor() {
      this.colortypes = this.colortypes.slice(0, this.colortypes.length - 1)
      this.changetable()
    },
    addsize() {
      this.sizetypes.push({ size: 'new' })
      this.changetable()
    },
    confirmsize() {
      this.changetable()
    },
    closesize() {
      this.sizetypes = this.sizetypes.slice(0, this.sizetypes.length - 1)
      this.changetable()
    },
    changetable() {
      var goodstore = []

      for (let i = 0; i < this.colortypes.length; i++) {
        for (let s = 0; s < this.sizetypes.length; s++) {
          goodstore.push(
            { color: this.colortypes[i].color, url: this.colortypes[i].url, size: this.sizetypes[s].size, pay: 10, num: 999 }
          )
        }
      }

      this.goodattrs = goodstore
      console.log(this.goodattrs)
    },
    arraySpanMethod({ row, column, rowIndex, columnIndex }) {
      /*   合并行故障暂停使用
                            if (columnIndex === 0) {
                                if (rowIndex % this.colortypes.length === 0) {
                                  return {
                                    rowspan: this.colortypes.length,
                                    colspan: 1
                                  };
                                } else {
                                  return {
                                    rowspan: 0,
                                    colspan: 0
                                  };
                                }
                              }
          */

    }

  }

}
</script>
<style>
.addgood{margin: 20px 20px;}
.good{padding-left: 32px;padding-right: 32px;}
.title{width: 100%;height: 48px;line-height: 48px;font-size: 16px;}
.cont{display: flex;flex-direction: row;flex-wrap: wrap;margin-top: 15px;margin-bottom: 15px;}
.left{width: 120px;line-height: 30px;text-align: right;font-size: 12px;}
.right{width: calc(100% - 120px);}
/* 自定义规格 */
.good-model{display: flex;flex-direction: column;}
.color-wrap{display: flex;flex-direction: row;flex-wrap: wrap;}

.color-type{display: flex;flex-direction: row;margin-bottom: 20px;margin-left: 15px;margin-right: 15px;}

.color-input{max-width: 200px;margin-right: 10px;}

/* 商品基本信息样式 */
.good-title{max-width: 700px;}
.main-rmb,.other-rmb{width: 200px;}
/* 物流信息样式 */
.detail-adress{max-width: 700px;}
.transplotpay,.otherpay{max-width: 200px;}
/* 提交按钮 */
.submit{display: flex;flex-direction: row;justify-content: space-around;margin-top: 40px;}
</style>

