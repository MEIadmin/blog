<template>
  <div>反向代理</div>
</template>
<script>
export default {
  data() {
    return {

    }
  }
}
</script>

