<template>
  <div class="mystore">
    <el-tabs v-model="activeName">
      <el-tab-pane label="全部商品" name="first"><all /></el-tab-pane>
      <el-tab-pane label="出售中的宝贝" name="second"><sell /></el-tab-pane>
      <el-tab-pane label="仓库中的宝贝" name="third"><store /></el-tab-pane>

    </el-tabs>
  </div>
</template>
<script>
import all from '@/components/mystore/all.vue'
import sell from '@/components/mystore/sell.vue'
import store from '@/components/mystore/store.vue'
export default {
  components: {
    all: all,
    sell: sell,
    store: store
  },
  data() {
    return {
      activeName: 'second'
    }
  }
}
</script>
<style>
.mystore{
  margin: 20px 20px;
}

</style>

